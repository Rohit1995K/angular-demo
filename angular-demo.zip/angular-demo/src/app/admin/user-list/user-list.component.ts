import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonServiceService } from './../../common-service.service';

declare var $;

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {

  @ViewChild('dataTable') table;
  public dataTable : any;
  item: any;
  userData: any;

  // export interface UserList {
  //   id :number,
  //   first_name:string,
  //   last_name:string,
  //   email:string,
  //   gender:string
  // }

  constructor(
    private commonService:CommonServiceService
  ) { }

  ngOnInit() {
    this.dataTable = $(this.table.nativeElement);
    this.dataTable.DataTable();    

    this.userList();
  }

  public userList(){
    
    this.commonService.getUserList().subscribe(resp => {
        this.userData = resp;
    });
  }
}
