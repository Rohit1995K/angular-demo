// import {NgModule} from '@angular/core';
// import {CommonModule} from "@angular/common";
// import {AdminRoutingModule, AdminComponentList} from "./admin-routing.module";
// import { ProfilePageComponent } from './profile-page/profile-page.component';

// @NgModule({
//     imports: [
//         CommonModule,
//         AdminRoutingModule,
//     ],
//     declarations: [
//         AdminComponentList,
       
//     ],
//     providers: [
       
//     ]

// })
// export class AdminModule {}


import {NgModule} from '@angular/core';
import {CommonModule} from "@angular/common";
import {AdminRoutingModule, AdminComponentList} from "./admin-routing.module";


@NgModule({
    imports: [
        CommonModule,
        AdminRoutingModule,
    ],
    declarations: [
        AdminComponentList,
       
    ],
    providers: [
       
    ]

})
export class AdminModule {}
