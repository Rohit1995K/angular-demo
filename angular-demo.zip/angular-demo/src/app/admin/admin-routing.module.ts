import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {ProfilePageComponent} from './profile-page/profile-page.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {UserListComponent} from './user-list/user-list.component';


const adminroutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: DashboardComponent,
                canActivate: [],
                data: {
                    title: 'Profile'
                }
            },
            {
                path: 'profile',
                component: ProfilePageComponent,
                canActivate: [],
                data: {
                    title: 'Profile'
                }
            },
            {
                path: 'user-list',
                component: UserListComponent,
                canActivate: [],
                data: {
                    title : 'User List'
                }
            }
        ]
    },
    
];

@NgModule({
    imports: [RouterModule.forChild(adminroutes)],
    providers: [
        
    ],
    exports: [RouterModule],
})
export class AdminRoutingModule {}

export const AdminComponentList = [
    UserListComponent,
    ProfilePageComponent,
    DashboardComponent,
];
