
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppComponent } from './app.component';
import { StoreModule } from '@ngrx/store';
import { HomePageComponent } from './home-page/home-page.component';
import { AboutPageComponent } from './about-page/about-page.component';
import { FullLayoutComponent } from "./layouts/full/full-layout.component";
//import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { AdminComponent } from './admin/admin.component';
import { FullNavbarComponent } from './layouts/full/full-navbar/full-navbar.component';
import { FullFooterComponent } from './layouts/full/full-footer/full-footer.component';
import { FullSidebarComponent } from './layouts/full/full-sidebar/full-sidebar.component';


@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    AboutPageComponent,
    FullLayoutComponent,
    //sDashboardComponent,
    AdminComponent,
    FullNavbarComponent,
    FullFooterComponent,
    FullSidebarComponent
 
  ],
  imports: [
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
  

    
  
  ],
  providers: [
   
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
