import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-navbar',
  templateUrl: './full-navbar.component.html',
  styleUrls: ['./full-navbar.component.scss']
})
export class FullNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
