import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from "@angular/router";


@Component({
    selector: 'app-full-layout',
    templateUrl: './full-layout.component.html',
    styleUrls: ['./full-layout.component.scss']
})

export class FullLayoutComponent implements OnInit {

   

    constructor(private elementRef: ElementRef, public router: Router) {
       
     }

    ngOnInit() {
       
    }

   

}