import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-sidebar',
  templateUrl: './full-sidebar.component.html',
  styleUrls: ['./full-sidebar.component.scss']
})
export class FullSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    
  }

  openNav() {
    //document.getElementById("mySidenav").style.width = "250px";
  }
  
  closeNav() {
    //document.getElementById("mySidenav").style.width = "0";
  }
  

}
