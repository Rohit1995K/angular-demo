import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FullSidebarComponent } from './full-sidebar.component';

describe('FullSidebarComponent', () => {
  let component: FullSidebarComponent;
  let fixture: ComponentFixture<FullSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FullSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FullSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
