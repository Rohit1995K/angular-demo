import {NgModule} from '@angular/core';
import {CommonModule} from "@angular/common";
import {UserRoutingModule, UserComponentList} from "./user-routing.module";


@NgModule({
    imports: [
        CommonModule,
        UserRoutingModule,
    ],
    declarations: [
        UserComponentList,
       
    ],
    providers: [
       
    ]

})
export class UserModule {}
