import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {ProfilePageComponent} from './profile-page/profile-page.component';
import {DashboardComponent} from './dashboard/dashboard.component';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: DashboardComponent,
                canActivate: [],
                data: {
                    title: 'dashboard'
                }
            },
            {
                path: 'profile',
                component: ProfilePageComponent,
                canActivate: [],
                data: {
                    title: 'Profile'
                }
            },
            
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    providers: [
        
    ],
    exports: [RouterModule],
})
export class UserRoutingModule {}

export const UserComponentList = [
    ProfilePageComponent,
    DashboardComponent
    

];
