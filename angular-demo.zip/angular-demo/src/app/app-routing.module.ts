import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { AboutPageComponent } from './about-page/about-page.component';
import { Full_ROUTES } from "./shared/routes/full-layout.routes";
import { FullLayoutComponent } from './layouts/full/full-layout.component';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'home',
    component: HomePageComponent,
    data: {
      title: 'Home Page'
    }
  },
  {
    path: 'about',
    component: AboutPageComponent,
    data: {
      title: 'Forgot Password'
    }
  },
  // {
  //   path: 'select-login',
  //   component: SelectUserComponent,
  //   canActivate : [AuthGuard],
  //   data: {
  //     title: 'Select Login'
  // }
  //},
  { path: '', component: FullLayoutComponent, data: { title: 'full Views' }, children: Full_ROUTES, canActivate: [] },
  // { path: '', component: ContentLayoutComponent, data: { title: 'content Views' }, children: CONTENT_ROUTES, canActivate: [] },
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})

export class AppRoutingModule {
}