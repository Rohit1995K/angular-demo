export const environment = {
  production: true,
  useMockApi: false
};
